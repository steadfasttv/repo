import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLlN0ZWFkRmFzdFRW')

name = b.b64decode('U3RlYWQgRmFzdFRW')

host = b.b64decode('aHR0cDovL2R1YmxpbmlwdHYuZGRucy5uZXQ=')

port = b.b64decode('ODM=')